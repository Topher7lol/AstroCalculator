# Import important modules
import tkinter as tk
import sys
import os
import random
import subprocess

def on_button_click(value):
    current = entry.get()
    entry.delete(0, tk.END)
    entry.insert(tk.END, str(current) + str(value))

def clear_entry():
    entry.delete(0, tk.END)

def calculate():
    try:
        result = eval(entry.get())
        entry.delete(0, tk.END)
        entry.insert(tk.END, str(result))
    except Exception as e:
        entry.delete(0, tk.END)
        entry.insert(tk.END, "Error")


def on_c_button_click():
    root.destroy()  # Close the current Tkinter window
    os.system("start run_calculator.bat")
    os._exit(0)  # Forcefully exit the Python process


def update_title():
    new_title = random.choice(title_list)
    root.title(new_title)
    root.after(2000, update_title)

# Create main window
root = tk.Tk()

# List of possible titles
title_list = ["Astro Calculator - Not A Scientific One.", "Astro Calculator - Astronomically Mathemative", "Astro Calculator - What's 9 + 10?", "Astro Calculator - You Aren't Albert Einstein!"]

# Entry widget for input and display
entry = tk.Entry(root, width=16, font=("Arial", 20), justify=tk.RIGHT, borderwidth=5)
entry.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

# Buttons
buttons = [
    ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
    ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
    ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
    ('0', 4, 0), ('C', 4, 1), ('=', 4, 2), ('+', 4, 3),
]

# Create buttons and add them to the grid
for (text, row, col) in buttons:
    button = tk.Button(root, text=text, padx=20, pady=20, font=("Arial", 16),
                       command=lambda value=text: on_button_click(value) if value != '=' else calculate() if value != 'C' else restart_program(),
                       bg="#f0f0f0", bd=5, relief=tk.GROOVE)
    button.grid(row=row, column=col, sticky="nsew", ipadx=5, ipady=5)


c_button = tk.Button(root, text="C", command=on_c_button_click)
c_button.grid(row=4, column=1, sticky="nsew", ipadx=5, ipady=5)


# Configure grid weights to make buttons expand proportionally
for i in range(5):
    root.grid_rowconfigure(i, weight=1)
    root.grid_columnconfigure(i, weight=1)

# Schedule the update_title function to run every 2 seconds
root.after(2000, update_title)


# Get the current script's directory
script_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the path to the icon file in the same directory
icon_path = os.path.join(script_dir, "icon.ico")

# Set the window icon
root.iconbitmap(icon_path)

# Run the main loop
root.mainloop()